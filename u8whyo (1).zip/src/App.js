import "./styles.css";
function App() {
  return (
    <div style={{width:'90%', margin: '0 auto'}}>
      <index />
    </div>
  );
}
export default App;
